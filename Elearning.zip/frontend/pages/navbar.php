<div class="centered-align icon-container">
    <a href="dashboard.php">
        <img src="images/dashboard-blue.png" class="small icon" id="dashboard" alt="dashboard">
    </a>
</div>
<div class="centered-align icon-container">
    <a href="courses.php">
        <img src="images/courses-blue.png" class="small icon" id="course" alt="courses">
    </a>
</div>
<div class="centered-align icon-container">
    <a href="calendar.php">
        <img src="images/calendar-blue.png" class="small icon" id="calendar" alt="calendar">
    </a>
</div>
<div class="centered-align icon-container">
    <a href="inbox.php">
        <img src="images/mail-blue.png" class="small icon" id="mail" alt="mail">
    </a>
</div>
<!--<div class="centered-align icon-container">
    <a href="#">
        <img src="images/help-center-blue.png" class="small icon" id="help-center" alt="help-center">
    </a>
</div>-->